<?php

require_once(__DIR__.'/class_query_mysqli.php');
require_once(__DIR__.'/models/jogos_model.php');
require_once(__DIR__.'/models/usuarios_model.php');
require_once(__DIR__.'/models/fornecedores_model.php');
require_once(__DIR__.'/constants.php');


$servidor = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'luanserver';

// Conecta-se ao banco de dados MySQL
$conexao = new mysqli(
    $servidor,
    $usuario,
    $senha,
    $banco
);

//Caso algo tenha dado errado, exibe uma mensagem de erro
if (mysqli_connect_errno()) {
    trigger_error(mysqli_connect_error());
}

echo mysqli_error($conexao);

?>