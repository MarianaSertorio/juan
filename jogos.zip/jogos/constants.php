<?php
session_start();
define('BASE_URL', 'http://127.0.0.1/jogos/');
