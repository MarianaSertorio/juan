<!DOCTYPE html>
<?php
require_once('./../includes/header.php');
$id = $_GET['id'];

$fornecedores_model = new fornecedores_model();
$fornecedores_model->setConexao($conexao);
$linha = $fornecedores_model->getByID($id);

?>
<div class="container">

<form class="col-md-6" action="action/atualizar_fornecedor.php" method="POST">
            
    <input name = "id" value = "<?php echo $linha['id']; ?>">
    <br>
    <div class="form-group">
        <label>Empresa</label>
        <input class="form-control" name="empresa" value = "<?php echo $linha['empresa']; ?>">
    </div>
    <br>
    <div class="form-group">
        <label>Plataforma</label>
        <input class="form-control" name="plataforma" value = "<?php echo $linha['plataforma']; ?>">
    </div>
            <br>
            <Button type="submit" class="btn btn-primary">Enviar</Button>
</form>
        <br>
        <!--<form class="col-md-6" action="listagem_fornecedores.php" method="POST">
            <Button type="submit" class="btn btn-primary">Consultar</Button>
        </form>
        <br>
        <form class="col-md-6" action="formulario_cadastrar_fornecedores.php" method="POST">
            <Button type="submit" class="btn btn-primary">Cadastrar</Button>
        </form>-->


<?php
        
include_once('../includes/footer.php');

?>


</html>