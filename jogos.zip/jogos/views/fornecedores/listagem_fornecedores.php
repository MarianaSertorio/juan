<?php

require_once('./../../conexao2.php');
include_once('./../includes/header.php');

$fornecedores_model = new fornecedores_model();
$fornecedores_model->setConexao($conexao);

$listagemFornecedores=$fornecedores_model->getAll();

echo '<br><br><a class="btn btn-success" href="'.BASE_URL.'views/fornecedores/formulario_cadastrar_fornecedores.php">Cadastrar</a><br><br>';
echo '<table class = "table table-striped">';
?>
<?php
    echo '
    <thead style = "text-align: center; font-family: Franklin Gothic Medium, Arial Narrow, Arial, sans-serif; font-size: 30px">
        <td>ID</td>
        <td>Empresa</td>
        <td>Plataforma</td>
        <td>Atualizar</td>
        <td>Deletar</td>
    </thead>    
    <tbody>';
    
        foreach ($listagemFornecedores as $key=>$dados) {
        echo '<tr style = "text-align: center; font-size: 15px">';
        echo '<td>' . $dados['id'] . '</td>';
        echo '<td>' . $dados['empresa'] . '</td>';
        echo '<td>' . $dados['plataforma'] . '</td>';
        echo '<td><a href="formulario_atualizar_fornecedores.php?id='.$dados['id'].'">Atualizar</a>'.'</td>';
        echo '<td><a href="action/deletar_fornecedor.php?id='.$dados['id'].'">Deletar</a>'.'</td>';
        echo '</tr>';
        }
        echo '
    </tbody>
</table>
';

echo '<br>';
echo '<br>';
?>