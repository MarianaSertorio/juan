<?php

require_once('./../../../conexao2.php');
$dados = [
    'id'=>$_POST['id'],
    'empresa'=>$_POST['empresa'],
    'plataforma'=>$_POST['plataforma']
];

$fornecedores_model = new fornecedores_model();
$fornecedores_model->setConexao($conexao);
$fornecedores_model->updateByID($dados['id'], $dados);

$error = mysqli_error($conexao);
if($error != ''){
    $_SESSION['msg_error'] = $error;
}else {
    $_SESSION['msg_success'] = 'Fornecedores Atualizado com Sucesso!';
}
header('location:../listagem_fornecedores.php');