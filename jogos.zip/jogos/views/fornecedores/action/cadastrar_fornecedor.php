<?php

require_once('./../../../conexao2.php');

$dados = [
    'empresa'=>$_POST['empresa'],
    'plataforma'=>$_POST['plataforma']
];

$fornecedores_model = new fornecedores_model();
$fornecedores_model->setConexao($conexao);
$fornecedores_model->inserir($dados);

/*$empresa = $_POST['empresa'];
$plataforma = $_POST['plataforma'];
$sql = 'INSERT INTO fornecedores (empresa,plataforma) 
VALUES ("'.$empresa.'","'.$plataforma.'")';*/
//$result = $conexao->query($sql);

$error = mysqli_error($conexao);
if($error != ''){
    $_SESSION['msg_error'] = $error;
}else {
    $_SESSION['msg_success'] = 'Fornecedor Cadastrado com Sucesso!';
}
header('location:../listagem_fornecedores.php');

echo '<br>';

?>

<link rel="stylesheet" href="https://cdn.usebootstrap.com/bootstrap/5.0.1/css/bootstrap.min.css">
  <script src="https://cdn.usebootstrap.com/bootstrap/5.0.1/js/bootstrap.bundle.min.js"></script>

  <form class="col-md-6" action="../../login/index.php">
                <Button type="submit" class="btn btn-primary">Login</Button>
    </form>