<?php

require_once('./../../../conexao2.php');

$dados = [
    'email'=>$_POST['email'],
    'senha'=>$_POST['senha']
];

$usuarios_model = new usuarios_model();
$usuarios_model->setConexao($conexao);
$usuarios_model->inserir($dados);


/*$email = $_POST['email'];
$senha = $_POST['senha'];
$sql = 'INSERT INTO usuarios (email,senha) 
VALUES ("'.$email.'","'.$senha.'")';
$result = $conexao->query($sql);*/

$error = mysqli_error($conexao);
if($error != ''){
    $_SESSION['msg_error'] = $error;
}else {
    $_SESSION['msg_success'] = 'Usuário Cadastrado com Sucesso!';
}
header('location:../index.php');

echo '<br>';

?>

<link rel="stylesheet" href="https://cdn.usebootstrap.com/bootstrap/5.0.1/css/bootstrap.min.css">
  <script src="https://cdn.usebootstrap.com/bootstrap/5.0.1/js/bootstrap.bundle.min.js"></script>

  <form class="col-md-6" action="../../login/index.php">
                <Button type="submit" class="btn btn-primary">Login</Button>
    </form>