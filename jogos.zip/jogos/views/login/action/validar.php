<?php

require_once('./../../../conexao2.php');

$usuarios_model = new usuarios_model();
$usuarios_model->setConexao($conexao);

$email = $_POST['email'];
$senha = $_POST['senha'];

$dadosUsuario = $usuarios_model->validarUsuario(
    $email,
    $senha
);

if(!empty($dadosUsuario)){
    $_SESSION['dados_usuario'] = $dadosUsuario;
    //echo 'Usuário '.$_SESSION['dados_usuario']['email'].' logado';
    header('Location: '.BASE_URL.'views/clientes/listagem.php');
}else{
    echo 'Usuário e senha inválidos';
}
?>