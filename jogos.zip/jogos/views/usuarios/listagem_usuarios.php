<?php

require_once('./../../conexao2.php');
include_once('./../includes/header.php');

$usuarios_model = new usuarios_model();
$usuarios_model->setConexao($conexao);

$listagemUsuarios=$usuarios_model->getAll();
echo '<br><br><a class="btn btn-success" href="'.BASE_URL.'views/usuarios/formulario_cadastrar_usuario.php">Cadastrar</a><br><br>';
echo '<table class = "table table-striped">';
    echo '
    <thead style = "text-align: center; font-family: Franklin Gothic Medium, Arial Narrow, Arial, sans-serif; font-size: 30px">
        <td>ID</td>
        <td>E-mail</td>
        <td>Senha</td>
        <td>Atualizar</td>
        <td>Deletar</td>
    </thead>    
    <tbody>';
    
        foreach ($listagemUsuarios as $key=>$dados) {
        echo '<tr style = "text-align: center; font-size: 15px">';
        echo '<td>' . $dados['id'] . '</td>';
        echo '<td>' . $dados['email'] . '</td>';
        echo '<td>' . $dados['senha'] . '</td>';
        echo '<td><a href="formulario_atualizar_usuario.php?id='.$dados['id'].'">Atualizar</a>'.'</td>';
        echo '<td><a href="action/deletar_usuario.php?id='.$dados['id'].'">Deletar</a>'.'</td>';
        echo '</tr>';
        }
        echo '
    </tbody>
</table>
';

echo '<br>';
echo '<br>';
?>