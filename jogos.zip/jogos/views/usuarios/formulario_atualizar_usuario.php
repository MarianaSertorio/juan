<!DOCTYPE html>
<?php
require_once('./../includes/header.php');
$id = $_GET['id'];

$usuarios_model = new usuarios_model();
$usuarios_model->setConexao($conexao);
$linha = $usuarios_model->getByID($id);

?>
<div class="container">

<form class="col-md-6" action="action/atualizar_usuario.php" method="POST">
            
    <input name = "id" value = "<?php echo $linha['id']; ?>">
    <br>
    <div class="form-group">
        <label>E-mail</label>
        <input class="form-control" name="email" value = "<?php echo $linha['email']; ?>">
    </div>
    <br>
    <div class="form-group">
        <label>Senha</label>
        <input class="form-control" name="senha" value = "<?php echo $linha['senha']; ?>">
    </div>
            <br>
            <Button type="submit" class="btn btn-primary">Enviar</Button>
</form>
        <br>
        <!--<form class="col-md-6" action="listagem_usuarios.php" method="POST">
            <Button type="submit" class="btn btn-primary">Consultar</Button>
        </form>
        <br>
        <form class="col-md-6" action="formulario_cadastrar_usuario.php" method="POST">
            <Button type="submit" class="btn btn-primary">Cadastrar</Button>
        </form>-->


<?php
        
include_once('../includes/footer.php');

?>


</html>