<?php


require_once('./../../conexao2.php');
session_destroy();

header('Location: '.BASE_URL.'views/login/');

?>