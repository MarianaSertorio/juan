<?php

require_once('./../../../conexao2.php');
$dados = [
    'id'=>$_POST['id'],
    'email'=>$_POST['email'],
    'senha'=>$_POST['senha']
];

$usuarios_model = new usuarios_model();
$usuarios_model->setConexao($conexao);
$usuarios_model->updateByID($dados['id'], $dados);

$error = mysqli_error($conexao);
if($error != ''){
    $_SESSION['msg_error'] = $error;
}else {
    $_SESSION['msg_success'] = 'Usuário Atualizado com Sucesso!';
}
header('location:../listagem_usuarios.php');