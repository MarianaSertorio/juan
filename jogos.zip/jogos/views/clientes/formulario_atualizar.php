<!DOCTYPE html>
<?php
require_once('./../includes/header.php');
$id = $_GET['id'];

$jogos_model = new jogos_model();
$jogos_model->setConexao($conexao);
$linha = $jogos_model->getByID($id);

?>
<div class="container">

<form class="col-md-6" action="action/atualizar.php" method="POST">
            
    <input name = "id" value = "<?php echo $linha['id']; ?>">
    <br>
    <div class="form-group">
        <label>Nome</label>
        <input class="form-control" name="nome" value = "<?php echo $linha['nome']; ?>">
    </div>
    <br>
    <div class="form-group">
        <label>Plataforma</label>
        <input class="form-control" name="plataforma" value = "<?php echo $linha['plataforma']; ?>">
    </div>
    <div class="form-group">
        <label>Data de Lançamento</label>
        <input class="form-control" name="data_criacao" value = "<?php echo $linha['data_criacao']; ?>">
    </div>
            <br>
            <Button type="submit" class="btn btn-primary">Enviar</Button>
</form>
        <br>
        <form class="col-md-6" action="listagem.php" method="POST">
            <Button type="submit" class="btn btn-primary">Consultar</Button>
        </form>
        <br>
        <form class="col-md-6" action="formulario_cadastrar.php" method="POST">
            <Button type="submit" class="btn btn-primary">Cadastrar</Button>
        </form>


<?php
        
include_once('../includes/footer.php');

?>


</html>