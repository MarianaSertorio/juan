<?php

require_once('./../../../conexao2.php');
$dados = [
    'id'=>$_POST['id'],
    'nome'=>$_POST['nome'],
    'plataforma'=>$_POST['plataforma'],
    'data_criacao'=>$_POST['data_criacao']
   
];

$jogos_model = new jogos_model();
$jogos_model->setConexao($conexao);
$jogos_model->updateByID($dados['id'], $dados);

$error = mysqli_error($conexao);
if($error != ''){
    $_SESSION['msg_error'] = $error;
}else {
    $_SESSION['msg_success'] = 'Jogo Atualizado com Sucesso!';
}
$error = mysqli_error($conexao);
if($error != ''){
    $_SESSION['msg_error'] = $error;
}else {
    $_SESSION['msg_success'] = 'Jogo Cadastrado com Sucesso!';
}

if(isset($_FILES['imagem'])){
    $extensao = strtolower(substr($_FILES['arquivo']['name'],-4));//pegar a extensao do arquivo
    $novo_nome =md5(time()). $extensao;//definir o nome do arquivo
    $diretorio ='../../../IMG/';//definir o diretorio do arquivo

    move_uploaded_file($_FILES['arquivo']['tmp_name'], $diretorio.$novo_nome);//efetuar o upload


    $sql="INSERT INTO jogos (imagem) VALUES ('".$novo_nome."')";
    $mysqli=mysqli_query($conexao,$sql);
    /*if($mysqli->query($sql)){
        $msg="Arquivo enviado com sucesso";
    }else{
        $msg="Falha ao enviar";
    }*/
}
header('location:../listagem.php');


