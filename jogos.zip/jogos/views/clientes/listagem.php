<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<div class="container">


    <?php

    require_once('./../../conexao2.php');
    include_once('./../includes/header.php');

    $jogos_model = new jogos_model();
    $jogos_model->setConexao($conexao);

    //Executa uma consulta de todos os clientes 
    //$sql = "SELECT * FROM fornecedores ".$sql_where;
    //$query = $conexao->query($sql);
    $listagemJogos = $jogos_model->getAll();
    
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Tabela Clientes</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
        <link rel='stylesheet' href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css'>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/inter-ui/3.19.3/inter.css'>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css'>
        <link rel='stylesheet' href='https://unpkg.com/vanilla-datatables@latest/dist/vanilla-dataTables.min.css'>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.min.css'>

    </head>
    <style>
        body {
            --background-color: #FAFAFA;
            --text-color: #52525B;
            --card-background-color: transparent;
            --card-border-color: rgba(24, 24, 27, 0.08);
            --card-box-shadow-1: rgba(24, 24, 27, 0.02);
            --card-box-shadow-1-y: 3px;
            --card-box-shadow-1-blur: 6px;
            --card-box-shadow-2: rgba(24, 24, 27, 0.04);
            --card-box-shadow-2-y: 2px;
            --card-box-shadow-2-blur: 7px;
            --card-label-color: #18181B;
            --card-icon-color: #18181B;
            --card-icon-background-color: rgba(24, 24, 27, 0.04);
            --card-icon-border-color: rgba(24, 24, 27, 0.1);
            --card-shine-opacity: .3;
            --card-shine-gradient: conic-gradient(from 225deg at 50% 50%, rgba(16, 185, 129, 0) 0deg, #10B981 25deg, #EDFAF6 285deg, #FFFFFF 345deg, rgba(16, 185, 129, 0) 360deg);
            --card-line-color: #E9E9E7;
            --card-tile-color: rgba(16, 185, 129, 0.08);
            --card-hover-border-color: rgba(24, 24, 27, 0.15);
            --card-hover-box-shadow-1: rgba(24, 24, 27, 0.05);
            --card-hover-box-shadow-1-y: 3px;
            --card-hover-box-shadow-1-blur: 6px;
            --card-hover-box-shadow-2: rgba(24, 24, 27, 0.1);
            --card-hover-box-shadow-2-y: 8px;
            --card-hover-box-shadow-2-blur: 15px;
            --card-hover-icon-color: #18181B;
            --card-hover-icon-background-color: rgba(24, 24, 27, 0.04);
            --card-hover-icon-border-color: rgba(24, 24, 27, 0.34);
            --blur-opacity: .1;
        }

        body.light {
            --background-color: #18181B;
            --text-color: white;
            --card-background-color: rgba(255, 255, 255, .015);
            --card-border-color: rgba(255, 255, 255, 0.1);
            --card-box-shadow-1: rgba(0, 0, 0, 0.05);
            --card-box-shadow-1-y: 3px;
            --card-box-shadow-1-blur: 6px;
            --card-box-shadow-2: rgba(0, 0, 0, 0.1);
            --card-box-shadow-2-y: 8px;
            --card-box-shadow-2-blur: 15px;
            --card-label-color: #FFFFFF;
            --card-icon-color: #D4D4D8;
            --card-icon-background-color: rgba(255, 255, 255, 0.08);
            --card-icon-border-color: rgba(255, 255, 255, 0.12);
            --card-shine-opacity: .1;
            --card-shine-gradient: conic-gradient(from 205deg at 50% 50%, rgba(16, 185, 129, 0) 0deg, #10B981 25deg, rgba(52, 211, 153, 0.18) 295deg, rgba(16, 185, 129, 0) 360deg);
            --card-line-color: #2A2B2C;
            --card-tile-color: rgba(16, 185, 129, 0.05);
            --card-hover-border-color: rgba(255, 255, 255, 0.2);
            --card-hover-box-shadow-1: rgba(0, 0, 0, 0.04);
            --card-hover-box-shadow-1-y: 5px;
            --card-hover-box-shadow-1-blur: 10px;
            --card-hover-box-shadow-2: rgba(0, 0, 0, 0.3);
            --card-hover-box-shadow-2-y: 15px;
            --card-hover-box-shadow-2-blur: 25px;
            --card-hover-icon-color: #34D399;
            --card-hover-icon-background-color: rgba(52, 211, 153, 0.1);
            --card-hover-icon-border-color: rgba(52, 211, 153, 0.2);
            --blur-opacity: .01;



        }

        body.toggle .grid * {
            transition-duration: 0s !important;
        }

        .day-night {
            cursor: pointer;
            position: absolute;
            right: 20px;
            top: 20px;
            opacity: 0.3;
        }

        .day-night input {
            display: none;
        }

        .day-night input+div {
            border-radius: 50%;
            width: 20px;
            height: 20px;
            position: relative;
            box-shadow: inset 8px -8px 0 0 var(--text-color);
            transform: scale(1) rotate(-2deg);
            transition: box-shadow 0.5s ease 0s, transform 0.4s ease 0.1s;
        }

        .day-night input+div:before {
            content: "";
            width: inherit;
            height: inherit;
            border-radius: inherit;
            position: absolute;
            left: 0;
            top: 0;
            transition: background-color 0.3s ease;
        }

        .day-night input+div:after {
            content: "";
            width: 6px;
            height: 6px;
            border-radius: 50%;
            margin: -3px 0 0 -3px;
            position: absolute;
            top: 50%;
            left: 50%;
            box-shadow: 0 -23px 0 var(--text-color), 0 23px 0 var(--text-color), 23px 0 0 var(--text-color), -23px 0 0 var(--text-color), 15px 15px 0 var(--text-color), -15px 15px 0 var(--text-color), 15px -15px 0 var(--text-color), -15px -15px 0 var(--text-color);
            transform: scale(0);
            transition: all 0.3s ease;
        }

        .day-night input:checked+div {
            box-shadow: inset 20px -20px 0 0 var(--text-color);
            transform: scale(0.5) rotate(0deg);
            transition: transform 0.3s ease 0.1s, box-shadow 0.2s ease 0s;
        }

        .day-night input:checked+div:before {
            background: var(--text-color);
            transition: background-color 0.3s ease 0.1s;
        }

        .day-night input:checked+div:after {
            transform: scale(1);
            transition: transform 0.5s ease 0.15s;
        }

        html {
            box-sizing: border-box;
            -webkit-font-smoothing: antialiased;
        }

        * {
            box-sizing: inherit;
        }

        *:before,
        *:after {
            box-sizing: inherit;
        }

        body {
            min-height: 100vh;
            display: flex;
            font-family: "Inter", Arial;
            background-color: var(--background-color);
            overflow: hidden;
        }

        body:before {
            content: "";
            inset: 0 -60% 65% -60%;
            background-image: radial-gradient(ellipse at top, #10B981 0%, var(--background-color) 50%);
            opacity: var(--blur-opacity);
        }



        button {
            position: relative;
            display: inline-block;
            cursor: pointer;
            outline: none;
            border: 0;
            vertical-align: middle;
            text-decoration: none;
            background: transparent;
            padding: 0;
            font-size: inherit;
            font-family: inherit;
        }

        button.learn-more {
            width: 12rem;
            height: auto;
        }

        button.learn-more .circle {
            transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
            position: relative;
            display: block;
            margin: 0;
            width: 3rem;
            height: 3rem;
            background: #282936;
            border-radius: 1.625rem;
        }

        button.learn-more .circle .icon {
            transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
            position: absolute;
            top: 0;
            bottom: 0;
            margin: auto;
            background: #fff;
        }

        button.learn-more .circle .icon.arrow {
            transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
            left: 0.625rem;
            width: 1.125rem;
            height: 0.125rem;
            background: none;
        }

        button.learn-more .circle .icon.arrow::before {
            position: absolute;
            content: "";
            top: -0.25rem;
            right: 0.0625rem;
            width: 0.625rem;
            height: 0.625rem;
            border-top: 0.125rem solid #fff;
            border-right: 0.125rem solid #fff;
            transform: rotate(45deg);
        }

        button.learn-more .button-text {
            transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            padding: 0.75rem 0;
            margin: 0 0 0 1.85rem;
            color: #282936;
            font-weight: 700;
            line-height: 1.6;
            text-align: center;
            text-transform: uppercase;
        }

        button:hover .circle {
            width: 100%;
        }

        button:hover .circle .icon.arrow {
            background: #fff;
            transform: translate(1rem, 0);
        }

        button:hover .button-text {
            color: #fff;
        }

        @supports (display: grid) {


            #container {
                grid-area: main;
                align-self: center;
                justify-self: center;
            }
        }

        #cadastrar:hover {
            cursor: pointer;
        }

        #deletar:hover {
            cursor: pointer;
        }

        #atualizar:hover {
            cursor: pointer;
        }
        img{
            width: 100px;
            height: 125px;
        }
    </style>

    <body>

        <div class="amizade">
            <div class="container" style="margin-left: 80px;">
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        echo '<br><br><a class="btn btn-success" href="' . BASE_URL . 'views/clientes/formulario_cadastrar.php">Cadastrar</a><br><br>';
                        ?>
                        <table class = "table table-striped" style="color: gray;">
                        <thead style = "text-align: center; font-family: Franklin Gothic Medium, Arial Narrow, Arial, sans-serif; font-size: 30px">
                                <tr>
                                    <th>ID</th>
                                    <th>Imagem</th>
                                    <th>Nome</th>
                                    <th>Plataforma</th>
                                    <th>Data de Lançamento</th>
                                    <th>Ativo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                 foreach ($listagemJogos as $key => $dados) {
                                    echo '<tr style = "text-align: center; font-size: 15px">';
                                    echo '<td>' . $dados['id'] . '</td>';
                                    ?>
                                   <!-- echo '<td><img src="../../IMG/'.$dados['imagem'].' alt="' . $dados['imagem'].'"></td>'; -->
                                   <?php
                                    echo '<td>' . $dados['nome'] . '</td>';
                                    echo '<td>' . $dados['plataforma'] . '</td>';
                                    echo '<td>' . $dados['data_criacao'] . '</td>';
                                    echo '<td>' . $dados['ativo'] . '</td>';
                                    echo '<td><a href="formulario_atualizar.php?id=' . $dados['id'] . '">Atualizar</a>' . '</td>';
                                    echo '<td><a href="action/deletar.php?id=' . $dados['id'] . '">Deletar</a>' . '</td>';
                                    echo '</tr>';
                                }
                                echo '
                                </tbody>
                                </table>
                                ';
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/86186/moment.js'></script>
        <script src='https://unpkg.com/vanilla-datatables@latest/dist/vanilla-dataTables.min.js'></script>
        <script>
            var table = new DataTable("table");
        </script>
    </body>

    </html>
    

    </body>

    </html>