<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
        crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>
<div class="container" >


<?php
class fornecedores_model{
    
    var $tabela = 'fornecedores';
    var $conexao = '';
    var $geradorQuery = '';

    /**
     * Constructor da Classe
     */
    function __construct(){
        $this->geradorQuery = new query_mysqli();
        $this->geradorQuery->setTabela($this->tabela);

    }
    
    /**
     * Configura a conexão do Model
     * 
     *  @param object $conexao Conexão com o Banco de Dados
     *  @return void $
     */
    
    function setConexao($conexao){
        $this->conexao = $conexao;
    }

    function getConexao(){
        return $this->$conexao;
    }

    /**
     * Valida os dados de login
     * 
     *  @param string $email Email do usuário
     *  @param string $senha Senha do usuário
     * 
     *  @return array
     */
    

    /*function validarUsuario($email, $senha){
        $sql = 'SELECT * FROM '.$this->tabela.' WHERE email="'.$email.'" AND senha="'.$senha.'"';
        $result = $this->conexao->query($sql);
        $dadosUsuario = $result->fetch_array();
        return $dadosUsuario;
    }*/

    /**
     * Retorna todas as linhas a tabela cliente
     *
     * @return array
     */
    function getAll(){
        $listagemFornecedores = array();
        $sql = $this->geradorQuery->selecionarTodos();
        $result = $this->conexao->query($sql);
        while($linha = $result->fetch_array()){
            $listagemFornecedores[] = $linha;
        }

        return $listagemFornecedores;
    }

    /**
     * Retorna os dados de um Jogo
     * 
     * @param int $id ID do Jogo
     * @return array
     */
    
    function getByID($id){
        $sql = $this->geradorQuery->getByID($id);
        $result = $this->conexao->query($sql);
        $linha = $result->fetch_array();
        //$linha['data_criacao'] = strtotime($linha['data_criacao']);
        //$linha['data_criacao'] = date('d/m/Y', $linha['data_criacao']);
        
        return $linha;

    }

    function updateByID($id, $dados){
        /*if(isset($dados['data_criacao'])){
            $dados['data_criacao'] = strtotime(str_replace('/', '-', $dados['data_criacao']));
            $dados['data_criacao'] = date('Y-m-d', $dados['data_criacao']);
        }*/

        $sql = $this->geradorQuery->updateByID($id, $dados);
        $result = $this->conexao->query($sql);
        return $result;
    }

    function inserir($dados){
        $sql = $this->geradorQuery->inserir($dados);
        $result = $this->conexao->query($sql);
        return $result;

    }

}