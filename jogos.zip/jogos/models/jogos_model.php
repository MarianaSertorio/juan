<?php
class jogos_model {
    var $tabela = 'jogos';
    var $conexao = '';
    var $geradorQuery = '';
    
    /**
     * Constructor da Classe
     */
    function __construct(){
        $this->geradorQuery = new query_mysqli();
        $this->geradorQuery->setTabela($this->tabela);

    }
    /**
     * Configura a conexão com o banco de dados
     *
     * @param object $conexao
     * @return void
     */
    function setConexao($conexao){
        $this->conexao = $conexao;
    }


    /**
     * Retorna todas as linhas a tabela cliente
     *
     * @return array
     */
    function getAll(){
        $listagemJogos = array();
        $sql = $this->geradorQuery->selecionarTodos();
        $result = $this->conexao->query($sql);
        while($linha = $result->fetch_array()){
            $linha['data_criacao'] = strtotime($linha['data_criacao']);
            $linha['data_criacao'] = date('d/m/Y', $linha['data_criacao']);
            $listagemJogos[] = $linha;
        }

        return $listagemJogos;
    }

    /**
     * Retorna os dados de um Jogo
     * 
     * @param int $id ID do Jogo
     * @return array
     */
    
    function getByID($id){
        $sql = $this->geradorQuery->getByID($id);
        $result = $this->conexao->query($sql);
        $linha = $result->fetch_array();
        $linha['data_criacao'] = strtotime($linha['data_criacao']);
        $linha['data_criacao'] = date('d/m/Y', $linha['data_criacao']);
        
        return $linha;

    }

    function updateByID($id, $dados){
        if(isset($dados['data_criacao'])){
            $dados['data_criacao'] = strtotime(str_replace('/', '-', $dados['data_criacao']));
            $dados['data_criacao'] = date('Y-m-d', $dados['data_criacao']);
        }

        $sql = $this->geradorQuery->updateByID($id, $dados);
        $result = $this->conexao->query($sql);
        return $result;
    }

    function inserir($dados){

        if(isset($dados['data_criacao'])){
        $dados['data_criacao'] = strtotime(str_replace('/', '-', $dados['data_criacao']));
        $dados['data_criacao'] = date('Y-m-d', $dados['data_criacao']);
        }

        $sql = $this->geradorQuery->inserir($dados);
        $result = $this->conexao->query($sql);
        return $result;

    }

}
