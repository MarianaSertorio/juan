<?php

session_start();
//$_SESSION['nome'] = 'Luan';
echo $_SESSION['nome'];


//$array = ['nome'=>' Silva'];
//echo $array['nome'];
?>