<?php

class query_mysqli{
    var $tabela='';

    
    
    /**
     * Retorna a query responsavel por selecionar todas as linhas da tabela
     * 
     * @return string
     */
    function selecionarTodos() {
        return 'SELECT * FROM '.$this->tabela;
    }
    /**
     * Retorna a query responsavel por apagar as linhas da tabela
     * 
     * @return string
     */
    function deletarBase() {
    return 'DELETE FROM '.$this->tabela;
    }
    /**
     * Retorna a query responsavel por apagar uma linha da tabela, utilizando o ID como identificador para a exclusão
     * @param integer $id Identificador da linha para a exclusão 
     * @return string
     */

    function deletarByID($id){
        return $this->deletarBase().' WHERE id='.$id;
    }
    /**
     * Configura a tabela para a criação das querys
     * 
     * @param string $tabela Tabela para a criação das querys
     * 
     * @return void
     */

    function setTabela($tabela){
        $this->tabela=$tabela;
    }
    /**
     * Retorna a tabela configurada
     * 
     * @return string
     */
    
    function getTabela() {
      return $this->tabela;  
    }

    /**
     * Retorna a query responsavel por selecionar
     * uma linha da tabela, utilizando o ID como identificador
     * 
     *  @param int
     *  @return string
     */

    function getByID($id){
        return 'SELECT * FROM ' . $this->tabela . ' WHERE id=' . $id;
    }

    function updateByID($id, $dados){
        $sql = 'UPDATE '.$this->tabela.' SET ';
        $campos = '';
        foreach ($dados as $key => $value) {
            if($campos != ""){
                $campos .=',';
            }
            if(!is_numeric($value)){
                $value = '"'.addslashes($value).'"';
            }
            $campos .= $key.'='.$value;
        }

        $sql .= $campos.' WHERE id='.$id;
        return $sql;
    }

    function inserir($dados){
        $sql = 'INSERT INTO ' . $this->tabela . '('; 
        $campos = '';
        $values = '';
        foreach ($dados as $key => $value) {
            if($campos != ""){
                $campos .=',';
            } if($values != ""){
                $values .=',';
            }
            if(!is_numeric($value)){
                $value = '"'.addslashes($value).'"';
            }
            $campos .= $key;
            $values .= $value;
            
        }
        $sql .= $campos.") VALUES (".$values.")";
            return $sql;
 
    }

}
?>